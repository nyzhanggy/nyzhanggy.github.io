//
//  FontTool.h
//  FontTool
//
//  Created by zhanggy on 2025/11/25.
//

#import <Foundation/Foundation.h>

//! Project version number for FontTool.
FOUNDATION_EXPORT double FontToolVersionNumber;

//! Project version string for FontTool.
FOUNDATION_EXPORT const unsigned char FontToolVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FontTool/PublicHeader.h>
@interface FontTool : NSObject
+ (NSString *)queryFontPath:(NSString *)fontname;
+ (BOOL)copyFont:(NSString *)fontname to:(NSString *)to;
@end
